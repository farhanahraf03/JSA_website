var aboutFlag = sessionStorage.getItem("projects_about_clicked");
if(aboutFlag === "yes")
{
  console.log(aboutFlag);
  var t = document.querySelector("#intro_container");
  var t_pos = t.getBoundingClientRect().top -107;
  window.scrollTo(0,t_pos);
  sessionStorage.setItem("projects_about_clicked", "no");
}

var projectsFlag = sessionStorage.getItem("projects_projects_clicked");
if(projectsFlag === "yes")
{
  console.log(projectsFlag);
  var t = document.querySelector("#our_projects_table");
  var t_pos = t.getBoundingClientRect().top -110;
  window.scrollTo(0,t_pos);
  sessionStorage.setItem("projects_projects_clicked", "no");
}

var mediaFlag = sessionStorage.getItem("projects_media_clicked");
if(mediaFlag === "yes")
{
  console.log(mediaFlag);
  var t = document.querySelector("#slideShowContainer");
  var t_pos = t.getBoundingClientRect().top -110;
  window.scrollTo(0,t_pos);
  sessionStorage.setItem("projects_media_clicked", "no");
}

var contactFlag = sessionStorage.getItem("projects_contact_clicked");
if(contactFlag === "yes")
{
  console.log(contactFlag);
  var t = document.querySelector("#contactContainer");
  var t_pos = t.getBoundingClientRect().top;
  window.scrollTo(0,t_pos);
  sessionStorage.setItem("projects_contact_clicked", "no");
}




function smoothScroll(target, duration){
    var target = document.querySelector(target);
    var targetPosition = target.getBoundingClientRect().top - 110//for navbar ;
    var startPosition = window.pageYOffset;

    var distance = targetPosition - startPosition; 

    var startTime = null;

    function animation(currentTime){
        if(startTime === null)startTime = currentTime; 
        var timeElapsed = currentTime - startTime;
        var run = ease(timeElapsed, startPosition, targetPosition, duration);
        window.scrollTo(0,run);
        if(timeElapsed<duration) requestAnimationFrame(animation);
    }

    function ease(t, b, c, d){
        t /= d/2;
        if(t < 1) return c / 2 * t * t + b;
        t--;
        return -c / 2 * (t * ( t - 2 ) - 1 ) + b;
    }

    requestAnimationFrame(animation);
}

function projectScroll() { document.getElementById("project_nav").addEventListener("click", smoothScroll("#our_projects_table",2000));}
function aboutScroll() { document.getElementById("about_nav").addEventListener("click", smoothScroll("#intro_container",1500));}
function mediaScroll() { document.getElementById("media_nav").addEventListener("click", smoothScroll("#slideShowContainer",2000));}
function contactScroll() {document.getElementById("contact_nav").addEventListener("click", smoothScroll("#contactContainer",2000));}

var x = window.innerWidth;
var t = document.getElementById("ttob").style.setProperty("left", x/2 - 56);

var imageSlides = document.getElementsByClassName('imageSlides');
var circles = document.getElementsByClassName('circle');
var leftArrow = document.getElementById('leftArrow');
var rightArrow = document.getElementById('rightArrow');
var counter = 0;

function hideImages() {
    for (var i = 0; i < imageSlides.length; i++) {
      imageSlides[i].classList.remove('visible');
    }
}

function removeDots() {
    for (var i = 0; i < imageSlides.length; i++) {
      circles[i].classList.remove('dot');
    }
}

function imageLoop() {
    var currentImage = imageSlides[counter];
    var currentDot = circles[counter];
    currentImage.classList.add('visible');
    removeDots();
    currentDot.classList.add('dot');
    counter++;
}

function arrowClick(e) {
    var target = e.target;
    if (target == leftArrow) {
      clearInterval(imageSlideshowInterval);
      hideImages();
      removeDots();
      if (counter == 1) {
        counter = (imageSlides.length - 1);
        imageLoop();
        imageSlideshowInterval = setInterval(slideshow, 10000);
      } else {
        counter--;
        counter--;
        imageLoop();
        imageSlideshowInterval = setInterval(slideshow, 10000);
      }
    } 
    else if (target == rightArrow) {
      clearInterval(imageSlideshowInterval);
      hideImages();
      removeDots();
      if (counter == imageSlides.length) {
        counter = 0;
        imageLoop();
        imageSlideshowInterval = setInterval(slideshow, 10000);
      } else {
        imageLoop();
        imageSlideshowInterval = setInterval(slideshow, 10000);
      }
    }
}

leftArrow.addEventListener('click', arrowClick);
rightArrow.addEventListener('click', arrowClick);

function slideshow() {
    if (counter < imageSlides.length) {
      imageLoop();
    } 
    else {
      counter = 0;
      hideImages();
      imageLoop();
    }
}

setTimeout(slideshow, 1000);
var imageSlideshowInterval = setInterval(slideshow, 5000);

var about_pos = getTop("#intro_container");
var project_pos = getTop("#our_projects_table");
var media_pos = getTop("#slideShowContainer");
var contact_pos = getTop("#contactContainer");

function getTop(target)
{
  var target = document.getElementById(target);
  var targetPos = target.getBoundingClientRect().top-110;
  return targetPos;
}

sessionStorage.setItem("about_pos",about_pos)
sessionStorage.setItem("project_pos",project_pos)
sessionStorage.setItem("media_pos",media_pos)
sessionStorage.setItem("contact_pos",contact_pos)