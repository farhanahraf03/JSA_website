function aboutFlagSwitch()
{
    sessionStorage.setItem("projects_about_clicked", "yes");
    window.location.href = "home.html"
}

function projectsFlagSwitch()
{
    sessionStorage.setItem("projects_projects_clicked", "yes");
    window.location.href = "home.html"
}

function mediaFlagSwitch()
{
    sessionStorage.setItem("projects_media_clicked", "yes");
    window.location.href = "home.html"
}

function contactFlagSwitch()
{
    sessionStorage.setItem("projects_contact_clicked", "yes");
    window.location.href = "home.html"
}